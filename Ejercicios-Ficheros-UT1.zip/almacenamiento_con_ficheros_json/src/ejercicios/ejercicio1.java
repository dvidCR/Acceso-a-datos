package ejercicios;

public class ejercicio1 {

}
