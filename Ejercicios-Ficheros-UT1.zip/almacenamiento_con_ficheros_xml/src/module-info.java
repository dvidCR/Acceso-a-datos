/**
 * 
 */
/**
 * 
 */
module almacenamientoXML {
	requires java.xml;
	requires java.compiler;
}